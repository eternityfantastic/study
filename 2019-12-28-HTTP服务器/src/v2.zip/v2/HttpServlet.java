package v2;

public abstract class HttpServlet {
    public abstract void doGet(Request req, Response resp);
}
